
package blood_donation_management_system;

//main Class
public class Blood_Donation_Management_System{

public static void main (String[] args ) {
    
     //Create login object and setting visible 
     Admin_login_form adminform=new Admin_login_form();      
     adminform.setVisible(true);
        
        
     
 }

}
